1  install the all needed packages

2  (1)under worker directory      npm start 
   (2)under server directory      npm start

3  http://localhost:3000
