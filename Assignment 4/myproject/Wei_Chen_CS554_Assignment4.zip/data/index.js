const userData = require('./data');

module.exports = {
    userData: userData
};